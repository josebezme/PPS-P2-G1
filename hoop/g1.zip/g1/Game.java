package hoop.g1;

public class Game {

	int ourScore;
	int theirScore;
	
	boolean selfGame;
	Move lastMove;
}
